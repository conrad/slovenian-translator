'use strict';

module.exports = {
  "beautiful" : "lepa"
};
